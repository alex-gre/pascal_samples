def test():
   print("test")

for i in range(1,11):
   print(i,{i, test(),  i})
